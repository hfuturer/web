<?php if (!defined('THINK_PATH')) exit();?>﻿<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0" />
	<title>临时书架_<?php echo ($TDK["webname"]); ?></title>
	<meta name="keywords" content="<?php echo ($TDK["keyword"]); ?>">
	<meta name="description" content="<?php echo ($TDK["description"]); ?>">
	<link rel="stylesheet" type="text/css" href="/Public/<?php echo ($theme); ?>/css/ptm.min.css?v<?php echo ($version); ?>" />
	<link rel="stylesheet" type="text/css" href="/Public/<?php echo ($theme); ?>/css/skin.min.css" />
	<link rel="stylesheet" type="text/css" href="/Public/<?php echo ($theme); ?>/css/font-awesome.min.css" />
	<script src="/Public/<?php echo ($theme); ?>/js/zepto.min.js"></script>
	<script src="/Public/<?php echo ($theme); ?>/js/bookcase.js?v<?php echo ($version); ?>"></script>
	<script>var view_rule = '<?php echo C('HOME_URL'); echo C('VIEW_RULE');?>', chapter_rule = '<?php echo C('HOME_URL'); echo C('CHAPTER_RULE');?>';</script>
</head>
<body>

<section class="ptm-content">
<header class="ptm-bar s72">
	<a class="ptm-pull-left" href="/"><span class="ptm-iconfont fa fa-home"></span></a>
	<div class="ptm-pull-left shu1"><?php echo ($TDK["catename"]); ?></div>
	<a class="ptm-pull-right" href="javascript:;">
		<span class="ptm-iconfont fa fa-search"></span>
	</a>

	<div class="s73">
	<a id="translatelink" class="ptm-pull-left"  href="javascript:;" onclick="javascript:history.back();"><span class="ptm-iconfont fa fa-reply"></span></a>
	</div>
	<div class="s732 s7322">
	<a id="translatelink" style="color:#ffffff;line-height:15px;" href="<?php echo U('/home/index/bookcase');?>">书架</a>
	</div>
	<div class="s733">
	<a id="translatelink" style="color:#ed424b;line-height:15px;" href="<?php echo ($catelist["top"]); ?>" >排行</a>
	</div>


</header>
	<div class="ptm-card d903 d905 d911">
		<div class="ptm-card-header ptm-clearfix d902">
				自己的小说书架
			<div class="ptm-pull-right"></div>
		</div>
		<div class="ptm-card-content bookcase">
			<div class="read_book"></div>
		</div>
		<?php if($pagehtml != ''): ?><div class="ptm-card-footer" id="pages">
			<?php echo ($pagehtml); ?>
		</div><?php endif; ?>
	</div>
	<script>loadbooker();</script>
</section>
<div class="ptm-line-x"></div>
<div class="footer">
	<p>本站系基于互联网搜索引擎技术为您提供信息检索服务。</p>
	<p>Copyright ©2017 <?php echo ($statcode); ?></p>
</div>
<section class="ptm-bar ptm-fix ptm-search">
	<div class="searchbox ptm-clearfix">
<?php if($comset["znsid"] != ''): ?><form action="http://zhannei.baidu.com/cse/search" name="searchbtm" method="get">
			<input type="hidden" name="s" value="<?php echo ($comset["znsid"]); ?>">
			<input name="q" placeholder="请输入小说名或作者名，勿错字" type="text" class="searchinput" required><button class="searchbtn ptm-btn-primary" type="submit">搜索</button>
		</form>
<?php else: ?>
		<form action="<?php echo U('/home/search');?>" name="searchbtm" method="post">
			<input type="hidden" name="action" value="search">
			<input name="q" placeholder="请输入小说名或作者名，勿错字" type="text" class="searchinput" required><button class="searchbtn ptm-btn-primary" type="submit">搜索</button>
		</form><?php endif; ?>
	</div>
</section>
<script type="text/javascript" src="/Public/<?php echo ($theme); ?>/js/zepto.min.js"></script>
<script type="text/javascript" src="/Public/<?php echo ($theme); ?>/js/base.js?v<?php echo ($version); ?>"></script>
<script type="text/javascript" src="/Public/trans.js?v<?php echo ($version); ?>"></script>
<?php if($comset["src"] != 'src'): ?><script src="//cdn.bootcss.com/jquery/2.2.1/jquery.min.js"></script>
<script src="//cdn.bootcss.com/jquery_lazyload/1.9.7/jquery.lazyload.min.js"></script>
<script>
$(function() {
	jQuery('[rel-class=lazyload]').lazyload({effect: "fadeIn"});
});
</script><?php endif; ?>
<?php echo ($advcode["global_footer"]["code_wap"]); ?>
</body>
</html>
<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Cache-Control" content="no-siteapp" />
	<meta http-equiv="Cache-Control" content="no-transform" />
	<title><?php echo ($TDK["title"]); ?></title>
	<meta name="keywords" content="<?php echo ($TDK["keyword"]); ?>" />
	<meta name="description" content="<?php echo ($TDK["description"]); ?>" />
	<link rel="canonical" href="<?php echo ($TDK["canonicalurl"]); ?>"/>
	<meta name="applicable-device" content="pc">
	<meta http-equiv="mobile-agent" content="format=html5; url=<?php echo ($TDK["canonicalurl_m"]); ?>">
	<link rel="stylesheet" href="/Public/<?php echo ($theme); ?>/css/style.css?v<?php echo ($version); ?>" />
	<script src="//cdn.bootcss.com/jquery/2.1.4/jquery.min.js"></script>
	<script type="text/javascript" src="/Public/<?php echo ($theme); ?>/js/header.js?v<?php echo ($version); ?>"></script>
	<script>var znsid = '<?php echo ($comset["znsid"]); ?>';</script>
</head>
<body>
<div id="wrapper">
	<div class="header">
	<div class="header_logo">
		<a href="<?php echo ($TDK["weburl"]); ?>" title="<?php echo ($TDK["webname"]); ?>"><?php echo ($TDK["webname"]); ?></a>
	</div>
			<div class="inner s96 cf">
				<form action="<?php echo U('/home/search');?>" method="post">
				<input type="hidden" name="action" value="search">
				<input name="q" placeholder="可以搜索 作者 书名" type="text" class="searchinput" required><button class="searchbtn" type="submit">搜索</button>
				</form>
			</div>
			<div class="inner s97 cf">
			<div class="daos1">
				<a href="<?php echo ($catelist["all"]); ?>">全部分类</a>
				<a href="<?php echo U('/quanben');?>">完结小说</a>
				<a href="<?php echo ($TDK["canonicalurl_m"]); ?>">手机版</a>
			</div>
			</div>
</div>
<div class="s92">
<div class="nav">
	<ul>
		<li><a href="<?php echo ($TDK["weburl"]); ?>" title="<?php echo ($TDK["webname"]); ?>">书城首页</a></li>
				<?php if(is_array($category)): foreach($category as $key=>$vo): ?><li class="tou2" ><a href="<?php echo ($vo['url']); ?>"><?php echo ($vo['name']); ?></a></li><?php endforeach; endif; ?>
		<li><a href="<?php echo ($catelist["top"]); ?>">排行榜单</a></li>
		<li><a href="<?php echo U('/home/index/bookcase');?>">书架</a></li>
	</ul>
</div>
</div>
	<?php echo ($advcode["list_1"]["code"]); ?>

<div class="all-pro-wrap box-center cf">
     <div class="range-sidebar fl">
          <div class="inner-wrap">
              <div class="selected">
			  <p>
			  <span>已选</span>
                <a class="all" href="javascript:" type="all"><?php echo ($TDK["catename"]); ?></a>
              </p>
              </div>
                <div class="select-list">
			      <div class="work-filter type-filter">
			           <h3>分类</h3>
					   <ul type="category">
					      <li><a href="<?php echo ($catelist["all"]); ?>">全部小说</a></li>
						  <li><a href="<?php echo U('/quanben');?>">完本小说</a></li>
					   		<?php if(is_array($category)): foreach($category as $key=>$vo): ?><li><a href="<?php echo ($vo['url']); ?>" <?php if($category[$key]['dir'] == $cate): ?>class="current"<?php endif; ?>><?php echo ($vo['name']); ?></a></li><?php endforeach; endif; ?>
					   </ul>
                   </div>
				 <div class="work-filter">
				    <h3>最新</h3>
					 <ul type="size">
					 <?php if(is_array($newestlist)): foreach($newestlist as $key=>$v): ?><li>
						<span class="s2"><a href="<?php echo ($v["rewriteurl"]); ?>" title="<?php echo ($TDK["catename"]); ?>推荐《<?php echo ($v["title"]); ?>》" target="_blank"><?php echo ($v["title"]); ?></a></span>
					  </li><?php endforeach; endif; ?>
					  </ul>
				   
				 </div> 
                </div>         
          </div>
     </div>
    <div class="main-content-wrap fl" data-l1="5">
	
                  <div class="right-book-list">
                      <ul>
					    <?php if(is_array($hotlist)): foreach($hotlist as $key=>$v): ?><li>
                          <div class="book-img">
                             <a href="<?php echo ($v['rewriteurl']); ?>" target="_blank" title="阅读<?php echo ($TDK["catename"]); ?>《<?php echo ($v['title']); ?>》">
						     <img <?php echo ($comset["src"]); ?>="<?php echo ($v['thumb']); ?>" alt="<?php echo ($v['title']); ?>" width="103" height="138" onerror="this.src='/Public/images/nocover.jpg'" />
                             </a>
                           </div>
                          <div class="book-info">
                             <h3><a href="<?php echo ($v['rewriteurl']); ?>" target="_blank" title="<?php echo ($v['title']); ?>小说信息"><?php echo ($v['title']); ?></a></h3>
                             <h4><a class="default"><?php echo ($v["author"]); ?></a></h4>
                             <p class="tag"><span class="org"><?php echo ($TDK["catename"]); ?></span><span class="pink"><?php if($articledb['full'] == 0): ?>连载<?php else: ?>完本<?php endif; ?></span><span class="blue"><?php echo ($v["views"]); ?>热度</span></p>
                             <p class="intro">
                               <?php echo ($v["description"]); ?>
                             </p>
                          </div>
                      </li><?php endforeach; endif; ?>
						</ul>
	              </div>
	  </div>
	  			 <div class="bos1">
				<h2><?php echo ($TDK["catename"]); ?>更新列表</h2>
				<ul>
					<?php if(is_array($articlelist)): foreach($articlelist as $key=>$v): ?><li class="item-cover">
						<a href="<?php echo ($v['rewriteurl']); ?>" title="好看的<?php echo ($TDK["catename"]); echo ($v['title']); ?>">
							<img <?php echo ($comset["src"]); ?>="<?php echo ($v['thumb']); ?>" alt="<?php echo ($v['title']); ?>小说阅读" onerror="this.src='/Public/images/nocover.jpg'" />
							<h3><?php echo ($v['title']); ?></h3>
						</a>
					</li><?php endforeach; endif; ?>
				</ul>
				<div class="pages">
					<?php echo ($pagehtml); ?>
				</div>
			</div>
</div>
	<div class="footer">
	<div class="footer_link"></div>
	<div class="footer_cont">
		<script>footer();</script><?php echo ($statcode); ?>
	</div>
</div>
<?php if($comset["src"] != 'src'): ?><script src="//cdn.bootcss.com/jquery_lazyload/1.9.7/jquery.lazyload.min.js"></script>
<script>
$(function() {
	$('[rel-class=lazyload]').lazyload({effect: "fadeIn"});
});
</script><?php endif; ?>
<?php echo ($advcode["global_footer"]["code"]); ?>
</div>
</body>
</html>